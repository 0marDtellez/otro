package com.example.luffy.navigations

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.luffy.presentacion.LoginScreen
import com.example.luffy.presentacion.login.LoginViewModel
import com.example.luffy.presentacion.registration.RegisterViewModel
import com.example.luffy.presentacion.registration.RegistrationScreen

@Composable
fun AppNavigation(){
    var contr= rememberNavController()
    NavHost(
        navController = contr,
        startDestination = Destinations.LoginScreen.route
    ){
        val viewModel= LoginViewModel()

        composable(route = Destinations.LoginScreen.route){

            if(viewModel.state.value.successLogin){
                LaunchedEffect(key1 =Unit){
                    contr.navigate(
                        Destinations.LoginScreen.createRoute(
                            viewModel.state.value.email,viewModel.state.value.pass
                        )){
                        popUpTo(Destinations.HomeScreen.route){
                            inclusive=true
                        }
                    }
                }
            }else{
                LoginScreen(
                    contr,
                    state=viewModel.state.value,
                    onLogin = viewModel::login,
                    onDissmissDialog = viewModel::hideErrorDialog,
                    onNavigateToRegister = {
                        contr.navigate(Destinations.RegistrationScreen.route)
                    }
                )
            }
        }
        val viewModel2 = RegisterViewModel()
        composable(Destinations.RegistrationScreen.route){
            RegistrationScreen(
                contr,
                //  state =viewModel2.state.value,
                onRegister =viewModel2::login,
                onBack = {contr.popBackStack()},
                onDismissDialog = viewModel2::hideErrorDialog
            )
        }

    }
}