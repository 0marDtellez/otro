package com.example.luffy.navigations


sealed class Destinations(
    val route:String,
    //val arguments:List<NamedNavArgument>
){
    object LoginScreen:Destinations(route = "LoginScree/{email}/{pass}"){
        fun createRoute(email:String,pass:String):String{
            return "LoginScreen/$email/$pass"
        }
    }

    object RegistrationScreen:Destinations(route = "RegistrationScreen")

    object HomeScreen:Destinations(route = "HomeScreen")
}
