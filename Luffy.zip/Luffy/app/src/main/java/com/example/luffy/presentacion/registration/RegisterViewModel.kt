package com.example.luffy.presentacion.registration

import android.util.Patterns
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.luffy.R
import com.example.luffy.presentacion.login.LoginState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class RegisterViewModel: ViewModel() {
    val state: MutableState<RegisterState> = mutableStateOf(RegisterState())
    fun login(
        name:String,
        email:String,
        phoneNumber:String,
        password:String,
        confirmPassword:String
    ){
        val errorMessages = if(
            name.isBlank()||
            email.isBlank()||
            phoneNumber.isBlank()||
            password.isBlank()||
            confirmPassword.isBlank()
        ){
            R.string.error_imput_empty
        }else if (!Patterns.PHONE.matcher(phoneNumber).matches()){
            R.string.error_not_e_valided_phone_number
        }else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            R.string.error_invalid_credentials
        }else if (password !=confirmPassword){
            R.string.error_incorrecty_repeated_password
        }
        else null
        errorMessages?.let {
            state.value=state.value.copy(errorMessages=errorMessages)
            return
        }
            viewModelScope.launch {
                state.value=state.value.copy(displayProgressBar = true)
                delay(3000)
                state.value=state.value.copy(displayProgressBar = true)
            }
        }

    fun hideErrorDialog(){
        state.value=state.value.copy(errorMessages = null )
    }
}